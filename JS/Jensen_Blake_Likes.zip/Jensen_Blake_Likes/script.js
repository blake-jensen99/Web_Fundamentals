function addOne(selector){
    var toAddTo = document.querySelector(selector)
    toAddTo.innerHTML++;
}