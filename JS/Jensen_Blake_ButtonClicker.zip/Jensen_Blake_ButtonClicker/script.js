function turnLogOff(element) {
    element.innerText = "Logout";
}

function hide(element) {
    element.remove();
}